# Simple JWT Authentication

A simple React practical demonstrating Authentication, JWT simulation, Token Generation, Token Storage, and Protected UI.

## Demo Login

- Username: `jasmeet`
- Password: `12345`

## Run

```bash
npm install
npm run dev
```

This project uses a simulated token with `btoa()`. It is for educational demonstration only and is not a real secure JWT implementation.
