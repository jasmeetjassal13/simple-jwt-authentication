import { useState } from "react";

function App() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [token, setToken] = useState(localStorage.getItem("token"));
  const [role, setRole] = useState(localStorage.getItem("role"));

  const handleLogin = () => {
    if (username === "jasmeet" && password === "12345") {
      const userData = {
        userId: 101,
        role: "student"
      };

      const simulatedToken = btoa(JSON.stringify(userData));

      localStorage.setItem("token", simulatedToken);
      localStorage.setItem("role", userData.role);

      setToken(simulatedToken);
      setRole(userData.role);

      alert("Login Successful!");
    } else {
      alert("Invalid username or password");
    }
  };

  const handleLogout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("role");
    setToken(null);
    setRole(null);
    setUsername("");
    setPassword("");
  };

  return (
    <div className="container">
      <h1>Simple JWT Authentication</h1>

      {!token ? (
        <div className="login-box">
          <h2>Login</h2>

          <input
            type="text"
            placeholder="Enter username"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
          />

          <input
            type="password"
            placeholder="Enter password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />

          <button onClick={handleLogin}>Login</button>

          <div className="demo">
            <p><b>Demo Login</b></p>
            <p>Username: jasmeet</p>
            <p>Password: 12345</p>
          </div>
        </div>
      ) : (
        <div className="dashboard">
          <h2>Welcome!</h2>
          <p>You are successfully logged in.</p>

          <div className="user-info">
            <p><b>User ID:</b> 101</p>
            <p><b>Role:</b> {role}</p>
            <p><b>Token:</b> {token}</p>
          </div>

          <div className="protected">
            <h2>Protected Dashboard</h2>
            <p>This dashboard is visible only when the user is logged in.</p>
          </div>

          <button className="logout" onClick={handleLogout}>Logout</button>
        </div>
      )}
    </div>
  );
}

export default App;
